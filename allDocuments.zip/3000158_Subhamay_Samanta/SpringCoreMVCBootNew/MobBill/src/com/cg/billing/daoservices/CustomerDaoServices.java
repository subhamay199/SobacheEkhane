package com.cg.billing.daoservices;
import java.util.List;

import com.cg.billing.beans.Customer;
public interface CustomerDaoServices {
	Customer save(Customer customer);
	Customer findOne(int customerID);
	public boolean removeCustomer(int customerID);
	public List<Customer> findAll();
}
