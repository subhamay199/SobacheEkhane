package com.cg.billing.daoservices;
import com.cg.billing.beans.Bill;

public interface BillDaoServices extends JpaRepository<BillDaoServices, Integer> {

Bill getMonthlyMobileBill(long mobileNo, String billMonth);

}
