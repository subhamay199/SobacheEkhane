package com.cg.billing.controllers;
@Controller
public class URIController {

}
